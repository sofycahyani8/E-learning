import 'package:flutter/material.dart';
import 'package:signin/splashscreen.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'SplashScreen',
    home: SplashScreen(),
  ));
}

